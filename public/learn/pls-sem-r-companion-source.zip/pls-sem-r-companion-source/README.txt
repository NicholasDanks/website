# PLS-SEM Using R — companion source

Source for the knitted companion document. To re-render you also need the
corporate reputation dataset, which is distributed by the publisher:
https://www.pls-sem.net/downloads/  (save as "Corporate Reputation Data.csv"
in this folder), then run: quarto render Quarto.qmd
